 import {Text} from 'react-native';
 
 export const Welcome = () => {
  return <Text>Oi, fulano, tudo bem ?</Text>;
};


